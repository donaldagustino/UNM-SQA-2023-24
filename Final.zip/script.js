export const API_KEY = "AIzaSyAMP3Mds95ZV-djMsAPkD0csytypX4WYhI";
